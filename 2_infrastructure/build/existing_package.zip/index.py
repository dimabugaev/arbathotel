import json

def lambda_handler(event, context):
    print("Hello from Lambda!")


    responseObj = {}
    responseObj["statusCode"] = 200
    responseObj["headers"] = {}
    responseObj["headers"]["Content-Type"] = 'application/json'
    responseObj['body'] = json.dumps('Hello from Lambda!')
    return responseObj